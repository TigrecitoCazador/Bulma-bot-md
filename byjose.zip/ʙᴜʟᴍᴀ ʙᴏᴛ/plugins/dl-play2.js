
import yts from 'yt-search'
import fg from 'api-dylux'
import { youtubedl, youtubedlv2 } from '@bochilteam/scraper'
let limit = 320
let handler = async (m, { conn, text, args, isPrems, isOwner, usedPrefix, command }) => {
  
    if (!text) throw `✳️ ${mssg.example} *${usedPrefix + command}* Lil Peep hate my life`
  let chat = global.db.data.chats[m.chat]
  let res = await yts(text)
  //let vid = res.all.find(video => video.seconds < 3600)
  let vid = res.videos[0]
  if (!vid) throw `✳️ Vídeo/Audio no encontrado`
  let isVideo = /vid$/.test(command)
  m.react('🍭') 
  
  let play = `
*╭═[ ✓ ]𝑴̷̸𝒖̷̸𝒔̷̸𝒊̷̸𝒄̷̸̷̸ 𝑩̷̸𝒖̷̸𝒍̷̸𝒎̷̸𝒂̷̸ 𝑩̷̸𝒐̷̸𝒕̷̸ 🍒*
  │╭─────────────···i
*┴│☂︎* 🌸 *${mssg.title}:* ${vid.title} || ᴮᵞ ᴮᵁᴸᴹᴬ
*⬡ │☂︎*  🌹 *${mssg.aploud}:* ${vid.ago}
*⬡ │☂︎*  ⌚ *${mssg.duration}:* ${vid.timestamp}
*⬡ │☂︎*  👀 *${mssg.views}:* ${vid.views.toLocaleString()}
*⬡ │☂︎ •  By © 𝑩𝒖𝒍𝒎𝒂-𝑩𝒐𝒕-𝑴𝑫* 
  *╰─────────────···i*
*╰───═[ ▐▎▎▎▎▐▏▏▏▏▎▐▍▎▏▏▏▏▐*

_Enviando..._` 
conn.sendFile(m.chat, vid.thumbnail, 'play', play, m, null, rcanal)
  
  let q = isVideo ? '360p' : '128kbps' 
try {
  let yt = await (isVideo ? fg.ytv : fg.yta)(vid.url, q)
  let { title, dl_url, quality, size, sizeB } = yt
  let isLimit = limit * 1024 < sizeB 

     await conn.loadingMsg(m.chat, '📥 Descargando', ` ${isLimit ? `≡  *FG YTDL*\n\n▢ *⚖️${mssg.size}*: ${size}\n▢ *🎞️${mssg.quality}*: ${quality}\n\n▢ _${mssg.limitdl}_ *+${limit} MB*` : '✅ Descarga Completada' }`, ["▬▭▭▭▭▭", "▬▬▭▭▭▭", "▬▬▬▭▭▭", "▬▬▬▬▭▭", "▬▬▬▬▬▭", "▬▬▬▬▬▬"], m)
     
	  if(!isLimit) conn.sendFile(m.chat, dl_url, title + '.mp' + (3 + /vid$/.test(command)), `
*╭═[ ✓ ]𝒀̷̸𝑻̷̸𝑫̷̸𝑳̷̸ 𝑩̷̸𝑼̷̸𝑳̷̸𝑴̷̸𝑨̷̸ 𝑩̷̸𝑶̷̸𝑻̷̸̸̷̷̸🍒*
  │╭─────────────···i
*┴│☂︎* *🌸Título* : ${title} || ᴮᵞ ᴮᵁᴸᴹᴬ
*⬡ │☂︎* *🍒️Calidad* : ${quality}
*⬡ │☂︎* *💗Peso* : ${size}
*⬡ │☂︎ • *By © 𝑩𝒖𝒍𝒎𝒂-𝑩𝒐𝒕-𝑴𝑫* 
*⬡ │☂︎ • *By © 𝐉̷̸𝐎̷̸𝐒̷̸𝐄̷̸𝐌̷̸𝐎̷̸𝐃̷̸𝐒̷̸* 
*⬡ │☂︎ • *🍒̷̶𝑺̷̸𝑰̷̸𝑵̷̸ 𝑻̷̸𝑬̷̸𝑻̷̸𝑨̷̸𝑺̷̸ 𝒀̷̷̸ 𝑪̷̸𝑼̷̸𝑳̷̸𝑶̷̸𝑺̷̸ 𝑵̷̸𝑶̷̸ 𝑯̷̸𝑨̷̸𝒀̷̸ 𝑷̷̸𝑨̷̸𝑹̷̸̷̸𝑨̷̸𝑰̷̸𝑺̷̸𝑶 ̷̸🍒̷̶*
  *╰─────────────···i*
*╰───═[ ▐▎▎▎▎▐▏▏▏▏▎▐▍▎▏▏▏▏▐*
`.trim(), m, false, { mimetype: isVideo ? '' : 'audio/mpeg', asDocument: chat.useDocument })
		m.react(done) 
  } catch {
  try {
//  let q = isVideo ? '360p' : '128kbps' 
  let yt = await (isVideo ? fg.ytmp4 : fg.ytmp3)(vid.url, q)
  let { title, dl_url, quality, size, sizeB } = yt
  let isLimit = limit * 1024 < sizeB 

     await conn.loadingMsg(m.chat, '📥 Descargando', ` ${isLimit ? `≡  *FG YTDL*\n\n▢ *⚖️${mssg.size}*: ${size}\n▢ *🎞️${mssg.quality}*: ${quality}\n\n▢ _${mssg.limitdl}_ *+${limit} MB*` : '✅ Descarga Completada' }`, ["▬▭▭▭▭▭", "▬▬▭▭▭▭", "▬▬▬▭▭▭", "▬▬▬▬▭▭", "▬▬▬▬▬▭", "▬▬▬▬▬▬"], m)
	  if(!isLimit) conn.sendFile(m.chat, dl_url, title + '.mp' + (3 + /2$/.test(command)), `
*╭═[ ✓ ]𝒀̷̸𝑻̷̸𝑫̷̸𝑳̷̸ 2 𝑩̷̸𝑼̷̸𝑳̷̸𝑴̷̸𝑨̷̸ 𝑩̷̸𝑶̷̸𝑻̷̸̸̷̷̸🍒*
  │╭─────────────···i
*┴│☂︎* *🌸${mssg.title}* : ${title} || ᴮᵞ ᴮᵁᴸᴹᴬ
*⬡ │☂︎* *🍒️${mssg.quality}* : ${quality}
*⬡ │☂︎* *💗${mssg.size}* : ${size}
*⬡ │☂︎ • *By © 𝑩𝒖𝒍𝒎𝒂-𝑩𝒐𝒕-𝑴𝑫* 
*⬡ │☂︎ • *By © 𝐉̷̸𝐎̷̸𝐒̷̸𝐄̷̸𝐌̷̸𝐎̷̸𝐃̷̸𝐒̷̸* 
*⬡ │☂︎ • *🍒̷̶𝑺̷̸𝑰̷̸𝑵̷̸ 𝑻̷̸𝑬̷̸𝑻̷̸𝑨̷̸𝑺̷̸ 𝒀̷̷̸ 𝑪̷̸𝑼̷̸𝑳̷̸𝑶̷̸𝑺̷̸ 𝑵̷̸𝑶̷̸ 𝑯̷̸𝑨̷̸𝒀̷̸ 𝑷̷̸𝑨̷̸𝑹̷̸̷̸𝑨̷̸𝑰̷̸𝑺̷̸𝑶 ̷̸🍒̷̶*
  *╰─────────────···i*
*╰───═[ ▐▎▎▎▎▐▏▏▏▏▎▐▍▎▏▏▏▏▐*
`.trim(), m, false, { mimetype: isVideo ? '' : 'audio/mpeg', asDocument: chat.useDocument })
		m.react(done) 
		
		 } catch (error) {
        m.reply(`❎ ${mssg.error}`)
    }
}

}
handler.help = ['play']
handler.tags = ['dl']
handler.command = ['play', 'playvid']

export default handler
