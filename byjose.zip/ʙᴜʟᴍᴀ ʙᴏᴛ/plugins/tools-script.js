import { promises } from 'fs'
import { join } from 'path'

let handler = async function (m, { conn, __dirname }) {
let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
  
m.reply(`
╭═══❮🍒𝑯𝑶𝑳𝑨 *%name*!!.🍒❯═══❯
║╭═══════❮ɪɴғᴏ ᴄʀᴇᴀᴅᴏʀ︎❯═════╮
║┃🌸ᴛᴇ ǫᴜɪᴇʀᴇs ʀᴏʙᴀʀ ᴀ ᴍɪ ʙᴏᴛ ʜᴇ🍒
║┃𝙲𝚁𝙴𝙰𝙳𝙾𝚁🌵:@${owner[0][0].split('@s.whatsapp.net')[0]}
║┃𝙳𝙴𝚂𝙰𝚁𝚁𝙾𝙻𝙰𝙳𝙾𝚁🌵:@${owner[0][0].split('@s.whatsapp.net')[0]}
║┃𝙶𝚁𝚄𝙿𝙾 𝙾𝙵𝙲🌵 :${bgp}
║┃𝙰𝚄𝚃𝙾𝚁🌵 : ${author}
║╰══════════❮ꨄ︎ꨄ︎❯═════════╯
╰═══❮💗©𝑩𝒚 𝑩𝒖𝒍𝒎𝒂 𝒃𝒐𝒕💗❯══❯
`.trim())
    
}

handler.help = ['script']
handler.tags = ['tools']
handler.command = ['sc', 'git', 'script'] 

export default handler
