
let handler = m => m
handler.all = async function (m) {
  for (const message in audioMsg) {
    if (new RegExp(`^${message}$`, 'i').test(m.text)) {
      this.sendFile(m.chat, audioMsg[message], 'audio.mp3', null, m, true)
      break
    }
  }
  return !0
 }

export default handler


let audioMsg = {
  'fino señores': './src/mp3/fino.mp3',
  'buenos días': 'https://k.top4top.io/m_2826iqdri1.mp3',
  'buenas tardes': 'https://b.top4top.io/m_2826v2zg51.mp3',
  'buenas noches': 'https://i.top4top.io/m_2826o8rfj1.mp3',
  'sad': 'https://h.top4top.io/m_2826mcim21.mp3',
  'Hola': './src/mp3/Hola.mp3',
  'a': './src/mp3/a.mp3',
  'admin': './src/mp3/admin.mp3',
  'Ara': './src/mp3/Ara.mp3',
  'Banate': './src/mp3/Banate.mp3',
  'baneado': './src/mp3/baneado.mp3',
  'bff': './src/mp3/bff.mp3',
  'bot': './src/mp3/bot.mp3',
  'boatarde': './src/mp3/boatarde.mp3',
  'Buenos-dias-2': './src/mp3/Buenos-dias-2.mp3',
  'cancion': './src/mp3/cancion.mp3',
  'chica lgante': './src/mp3/chica lgante.mp3',
  'DiagnosticadoConGay': './src/mp3/DiagnosticadoConGay.mp3',
  'dylan1': './src/mp3/dylan1.mp3',
  'Elmo': './src/mp3/Elmo.mp3',
  'Epico': './src/mp3/Epicomp3',
  'Es putoo': './src/mp3/Es putoo.mp3',
  'Feliz cumple': './src/mp3/Feliz cumple.mp3',
  'fiesta': './src/mp3/fiesta.mp3',
  'Fiesta1': './src/mp3/Fiesta1.mp3',
  'fino': './src/mp3/fino.mp3',
  'gay2': './src/mp3/gay2.mp3',
  'gemi2': './src/mp3/gemi2.mp3',
  'hentai': './src/mp3/hentai.mp3',
  'insultar': './src/mp3/insultar.mp3',
  'menu': './src/mp3/menu.mp3',
  'Noche': './src/mp3/Noche.mp3',
  'oh_tio': './src/mp3/oh_tio.mp3',
  'Onichan': './src/mp3/Onichan.mp3',
  'ora': './src/mp3/ora.mp3',
  'fino señores': './src/mp3/Hola.mp3',
  'otaku': './src/mp3/otaku.mp3',
  'pato': './src/mp3/pato.mp3',
  'rawr': './src/mp3/rawr.mp3',
  'shitpost': './src/mp3/shitpost.mp3',
  'siu': './src/mp3/siu.mp3',
  'Te-amo': './src/mp3/Te-amo.mp3',
  'toma': './src/mp3/toma.mp3',
  'Tu': './src/mp3/Hola.mp3',
  'UwU': './src/mp3/UwU.mp3',
  'vengo': './src/mp3/vengo.mp3',
  'vete a la verga': './src/mp3/vete a la verga.mp3',
  'viernes': './src/mp3/viernes.mp3',
  'vivan': './src/mp3/vivan.mp3',
  'Yamete-kudasai': './src/mp3/Yamete-kudasai.mp3',
  '@51967418366|@51975985721': 'https://l.top4top.io/m_2492i4mdu1.mp3'
}
