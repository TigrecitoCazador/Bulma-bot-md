import fetch from 'node-fetch';
export async function before(m, { conn }) {
   let pp = await this.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/1ZxrXKJ/avatar-contact.jpg');

  // Respuesta con enlace de notificación 
  global.rpl = {
    contextInfo: {
mentionedJid: [m.sender],
    	forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaType: 'VIDEO',
        description: 'support group',
        title: 'ᥫ᭡⃟☻ＮＯＴＩＦＩＣＡＣＩＯ́Ｎ ☻⃟ᥫ᭡',
        body: 'ʙᴜʟᴍᴀ ᴍᴅ-𝗕𝗢𝗧 𝗠𝗗 ',
        sourceUrl: global.linkgc, thumbnail: catalogo2
      }
    }
  };
  
  // Respuesta con enlace de descarga 
  global.rcanal = {
    contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaUrl: '☂︎ ᴄʀᴇᴀᴅᴏ ʙʏ ᴊᴏsᴇ ʏᴛ',
        mediaType: 'VIDEO',
        description: 'canal del grupo',
        title: '🍓┆ᴅᴇsᴄᴀʀɢᴀs ʙʏ ʙᴜʟᴍᴀ ᴍᴅ┊🌸',
        body: 'ғᴇᴄʜᴀ ᴀᴄᴛᴜᴀʟ: ' + fecha,
        thumbnailUrl: "https://telegra.ph/file/998e5578046df29c23b25.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  }

  // Respuesta con enlace de PayPal
  global.rpyp = {
    contextInfo: {
mentionedJid: [m.sender],
    	forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaUrl: fgpyp,
        mediaType: 'VIDEO',
        description: 'Donate',
        title: '🍓┆ᴅᴇsᴄᴀʀɢᴀs ᴅᴇ ɪᴍᴀɢᴇɴᴇs┊🍒',
        body: 'ғᴇᴄʜᴀ ᴀᴄᴛᴜᴀʟ: ' + fecha,
        thumbnailUrl: "https://telegra.ph/file/9629c5c4a74246211ad1b.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  };

  // Respuesta con enlace de Instagram
  global.rpig = {
    contextInfo: {
mentionedJid: [m.sender],
    	forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaUrl: fgig,
        mediaType: 'VIDEO',
        description: 'Sigueme por Instagram',
        title: 'ʙᴜʟᴍᴀ ᴍᴅ┊ᴍᴜʟᴛɪ ᴊᴜᴇɢᴏs🍒',
        body: 'ғᴇᴄʜᴀ ᴀᴄᴛᴜᴀʟ: ' + fecha,
        thumbnailUrl: "https://telegra.ph/file/378eecdf7014a0061a78b.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  };
//Respuesta con enlace de creador
global.cr7 = {
    contextInfo: {
mentionedJid: [owner[0][0] + '@s.whatsapp.net'],
    	forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaUrl: fgig,
        mediaType: 'VIDEO',
        description: 'Sigueme por Instagram',
        title: '🍓┆sᴛᴀᴛᴜs ʙʏ ʙᴜʟᴍᴀ ᴍᴅ 🍏',
        body: wm,
        sourceUrl: global.linkgc, thumbnail: imgmenu2
      }
    }
  };
//Respuesta con mensaje de sticker
//Respuesta de minar
global.minas = {
    contextInfo: {
mentionedJid: [m.sender],
    	forwardingScore: 9999,
				isForwarded: true,
      externalAdReply: {
        mediaUrl: fgig,
        mediaType: 'VIDEO',
        description: 'Sigueme por Instagram',
        title: '🛍️ ʙᴜʟᴍᴀ - ᴍᴅ 🛍️',
        body: '¡ɪʟᴜᴍɪɴᴀᴛᴇ ᴄᴏɴ sᴏɴʀɪsᴀs',
        thumbnailUrl: "https://telegra.ph/file/58f5dc8d027e1691a1ef9.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  };

global.pegatina = {
    contextInfo: {
mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: true,
        mediaUrl: fgyt,
        mediaType: 'VIDEO',
        description: 'Suscribete: ' + fgyt,
        title: '🍓┆sᴛɪᴄᴋᴇʀs ʙʏ ʙᴜʟᴍᴀ ᴍᴅ┊🍏',
        body: 'ғᴇᴄʜᴀ ᴀᴄᴛᴜᴀʟ xᴅ: ' + fecha,
        thumbnailUrl: "https://telegra.ph/file/07052ba2e32d65ef3b47f.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  };
 // Respuesta con enlace de YouTube
  global.rpyt = {
    contextInfo: {
mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: true,
        mediaUrl: fgyt,
        mediaType: 'VIDEO',
        description: 'Suscribete: ' + fgyt,
        title: '🍓┆ʟᴏɢᴏs ᴘᴇʀsᴏɴᴀʟɪᴢᴀᴅᴏs ʙʏ ʙᴜʟᴍᴀ ᴍᴅ┊🍏',
        body: 'ғᴇᴄʜᴀ ᴀᴄᴛᴜᴀʟ: ' + fecha,
        thumbnailUrl: "https://telegra.ph/file/07052ba2e32d65ef3b47f.jpg",
        sourceUrl: '☂︎ ᴄʀᴇᴀᴛᴇᴅ ʙʏ ᴊᴏsᴇ🌵'
      }
    }
  }
  
  
  
}