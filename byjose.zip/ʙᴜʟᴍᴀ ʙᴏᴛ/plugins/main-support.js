 
let media = './src/grupos.jpg'
let handler = async (m, { conn }) => {

m.reply(`
Hᴏʟᴀ %name*!!. ᴛᴇ ɪɴᴠɪᴛᴏ ᴀ ғᴏʀᴍᴀʀ ᴘᴀʀᴛᴇ ᴅᴇ ᴍɪ ᴄᴏᴍᴜɴɪᴅᴀᴅ 🍒🪁 ᴀǫᴜɪ ᴇsᴛᴀ ʟᴀ ʟɪsᴛᴀ ᴅᴇ ɢʀᴜᴘᴏs ᴅᴇ 𝑩𝒖𝒍𝒎𝒂 𝑩𝒐𝒕 🍓

*╔══❖•ೋ°𝑮𝑹𝑼𝑷𝑶𝑺 𝑫𝑬 *${botName}ೋ•❖═══╗*
┃ඬ⃟ 🧸❖ ── ✦ ──『✙』── ✦ ── ❖
┃ඬ⃟ 🧸𝑪𝒂𝒏𝒂𝒍 : ${fgcanal}
┃ඬ⃟ 🧸𝑮𝒓𝒖𝒑𝒐1 : ${bgp}
┃ඬ⃟ 🧸𝑮𝒓𝒖𝒑𝒐2 : ${bgp2}
┃ඬ⃟ 🧸𝑮𝒓𝒖𝒑𝒐3 : ${bgp3}
┃ඬ⃟ 🧸❖ ── ✦ ──『✙』── ✦ ── ❖
*╚═══❖•ೋ°           °ೋ•❖═══╝*`)

let pp = './src/grupos.jpg'
/*conn.sendButton(m.chat, m2, mssg.ig, pp, [
      ['⏍ Info', `${usedPrefix}botinfo`],
      ['⌬ Grupos', `${usedPrefix}gpdylux`]
    ],m, rpyt)*/
}
handler.help = ['support']
handler.tags = ['main']
handler.command = ['grupos', 'groups', 'support'] 

export default handler
