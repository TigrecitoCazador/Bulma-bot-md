
import yts from 'yt-search'
let handler = async (m, { conn, command, text, usedPrefix }) => {
	
  if (!text) throw `✳️ ${mssg.example} *${usedPrefix + command}* Lil Peep hate my life`
	let res = await yts(text)
	let vid = res.videos[0]
	if (!vid) throw `✳️ Vídeo/Audio no encontrado`
	let { title, description, thumbnail, videoId, timestamp, views, ago, url } = vid
	//const url = 'https://www.youtube.com/watch?v=' + videoId
	m.react('🍒') 
	let play = `
*╭═[ ✓ ]𝑴̷̸𝒖̷̸𝒔̷̸𝒊̷̸𝒄̷̸̷̸ 𝑩̷̸𝒖̷̸𝒍̷̸𝒎̷̸𝒂̷̸ 𝑩̷̸𝒐̷̸𝒕̷̸ 🍒*
  │╭─────────────···i
*┴│☂︎* 📌 *${mssg.title()}* : ${title} || ᴮᵞ ᴮᵁᴸᴹᴬ
*⬡ │☂︎* 🍧*${mssg.uploud()}:* ${ago}
*⬡ │☂︎* ⌚ *${mssg.duration}:* ${timestamp}
*⬡ │☂︎* 👀 *${mssg.views}:* ${views}
*⬡ │☂︎ •  By © 𝑩𝒖𝒍𝒎𝒂-𝑩𝒐𝒕-𝑴𝑫* 
  *╰─────────────···i*
*╰───═[ ▐▎▎▎▎▐▏▏▏▏▎▐▍▎▏▏▏▏▐*

 await conn.sendButton(m.chat, play, mssg.ig, thumbnail, [
    ['🎶 MP3', `${usedPrefix}fgmp3 ${url}`],
    ['🎥 MP4', `${usedPrefix}fgmp4 ${url}`]
  ], m, rpl)
}
handler.help = ['play']
handler.tags = ['dl']
handler.command = ['play', 'playvid']
handler.disabled = true

export default handler
