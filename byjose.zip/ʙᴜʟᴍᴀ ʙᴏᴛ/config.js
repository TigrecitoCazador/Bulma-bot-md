import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.owner = [
  ['51975985721', '©🌵𝐁̷̸𝐘̷̸ 𝐄̷̸𝐋̷̸𝐁̷̸𝐄̷̸𝐑̷̸ 𝐌̷̸𝐎̷̸𝐃̷̸𝐒̷̸̷̸̶', true],
  ['51967418366','©👑𝐁̷̸𝐘̷̸ 𝐊̷̸𝐄̷̸𝐕̷̸𝐈̷̸𝐍̷̸ 𝐌̷̸𝐎̷̸𝐃̷̸𝐒̷̸',true]
  ['51922239721','©🍧𝐁̷̸𝐘̷̸ͧ͢͜͡͞͞𝐌̷̸𝐀̷̸̸͖ͯ͜͢͝͡𝐑𝐈̷̸𝐎̷̸ ̷̸',true]
] //Numeros de owner 

global.mods = [''] 
global.prems = ['', '']
global.APIs = { // API Prefix
  // name: 'https://website' 
  nrtm: '',
  fgmods: ''
}
global.APIKeys = { // APIKey Here
  // 'https://website': 'apikey'
  '': '' //--- 100 de límite diario --- 
}

// Sticker WM
global.packname = '' 
global.author = '' 

//--info FG
global.botName = ''
global.fgig = '' 
global.fgsc = '' 
global.fgyt = ''
global.fgpyp = ''
global.fglog = '' 

//--- Grupos WA
global.fgcanal = ''
global.bgp = ''
global.bgp2 = ''
global.bgp3 = '' //--Canal 2

global.wait = '⌛ _Cargando..._\n*▬▬▬▭*'
global.rwait = '⌛'
global.dmoji = '🤭'
global.done = '✅'
global.error = '❌' 
global.xmoji = '🔥' 

global.multiplier = 69 
global.maxwarn = '2' // máxima advertencias

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
